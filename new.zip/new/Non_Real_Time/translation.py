import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"  # 解決 OpenMP 重複初始化的問題，若無此問題可註解掉這行

from faster_whisper import WhisperModel

# 指定輸入和輸出目錄，可任意更改
input_directory = "translation_file/input/example"
output_directory = "translation_file/output/example"

# 確保輸出目錄存在
os.makedirs(output_directory, exist_ok=True)

# 加載 Faster-Whisper 模型
model = WhisperModel("large-v2", device="cuda", compute_type="float16")

# 處理目錄中的每個 MP3 文件
for filename in os.listdir(input_directory):
    if filename.endswith(".mp3"):
        file_path = os.path.join(input_directory, filename)
        output_file = os.path.join(output_directory, f"{filename[:-4]}.txt")
        print(f"Transcribing {filename}...")

        try:
            # 轉錄音頻
            segments, _ = model.transcribe(file_path, beam_size=5)

            # 將字幕結果保存到文件
            with open(output_file, "w", encoding="utf-8") as f:
                for segment in segments:
                    f.write(f"[{segment.start:.2f}s -> {segment.end:.2f}s]: {segment.text}\n")

            print(f"Transcription saved to {output_file}")
        except Exception as e:
            print(f"Error processing {filename}: {e}")
