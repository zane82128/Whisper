import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"  # 解決 OpenMP 重複初始化的問題，若無此問題可註解掉這行

import sounddevice as sd
from faster_whisper import WhisperModel
import queue

# 參數設置
SAMPLING_RATE = 16000  # Whisper 模型要求的取樣率
CHUNK_DURATION = 2  # 每塊音頻的持續時間（秒）
CHUNK_SIZE = int(SAMPLING_RATE * CHUNK_DURATION)  # 每塊音頻的樣本數量

# 創建音頻隊列
audio_queue = queue.Queue()

# 回調函數：從麥克風即時獲取音頻數據
def audio_callback(indata, frames, time, status):
    if status:
        print(f"Warning: {status}")  # 如果有錯誤或警告，打印出提示
    audio_queue.put(indata.copy())  # 將獲取的音頻數據放入隊列

# 加載 Faster-Whisper 模型
model = WhisperModel("large-v2", device="cuda", compute_type="float16")

# 即時轉錄函數
def realtime_transcription():
    print("開啟麥克風進行轉譯...按下 Ctrl+C 終止")
    total_audio_time = 0  # 總音頻時間，用於時間累加

    try:
        # 開啟音頻輸入流
        with sd.InputStream(
            samplerate=SAMPLING_RATE,
            channels=1,
            dtype="float32",
            callback=audio_callback,
            blocksize=CHUNK_SIZE
        ):
            while True:
                # 從queue中獲取音頻塊
                if not audio_queue.empty():
                    audio_chunk = audio_queue.get()
                    
                    # transcript
                    result, _ = model.transcribe(audio_chunk.flatten(), language="zh", beam_size=10)  # language = zh代表中文，beam size可自己調，size越大則翻譯越準確，但越吃性能
                    for segment in result:
                        start_time = total_audio_time + segment.start  # 計算開始時間
                        end_time = total_audio_time + segment.end  # 計算結束時間
                        print(f"[{start_time:.2f}s -> {end_time:.2f}s]: {segment.text}")
                    
                    total_audio_time += len(audio_chunk) / SAMPLING_RATE  # 累加已處理的音頻時間

    except KeyboardInterrupt:
        print("已停止")  # 捕捉到鍵盤中斷後，結束轉譯

# 主函數
if __name__ == "__main__":
    realtime_transcription()
