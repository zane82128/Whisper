# This file is for simulating real-time scene, in case you don't have a microphone right now.

import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE" # 解決 OpenMP 重複初始化的問題，若無此問題可註解掉這行

from opencc import OpenCC
import librosa
import numpy as np
import time
from faster_whisper import WhisperModel

# 參數設置
AUDIO_PATH = "example.mp3" # audio file that you want to transcript
SAMPLING_RATE = 16000  # Whisper 的sample rate
CHUNK_DURATION = 2  # 每個chunk的持續時間
CHUNK_SIZE = int(SAMPLING_RATE * CHUNK_DURATION)

# load faster whisper, using large-v2 model
model = WhisperModel("large-v2", device="cuda", compute_type="float16")

# loading audio file
def load_audio(filepath):
    audio, _ = librosa.load(filepath, sr=SAMPLING_RATE, mono=True, dtype=np.float32)
    return audio

converter = OpenCC("s2t")  # 's2t' 表示簡體到繁體

# 模擬即時音頻處理
def simulate_realtime_transcription(audio, chunk_size):
    total_chunks = len(audio) // chunk_size  # 計算音頻可被分割的塊數
    print(f"音頻總時長：{len(audio) / SAMPLING_RATE:.2f} 秒")
    
    # 初始化累計時間變量，用於追蹤處理的總時長
    cumulative_time = 0.0
    
    for i in range(total_chunks + 1):
        start = i * chunk_size  # 當前音頻塊的開始索引
        end = start + chunk_size  # 當前音頻塊的結束索引
        audio_chunk = audio[start:end]  # 提取音頻塊
        
        if len(audio_chunk) == 0:  # 若音頻塊長度為零，則結束迴圈
            break
        
        # 使用模型對當前音頻塊進行轉錄
        result, _ = model.transcribe(audio_chunk, language="zh", beam_size=10) # language = zh代表中文，beam size可自己調，size越大則翻譯越準確，但越吃性能
        for segment in result:
            # 根據當前累計時間計算全局開始與結束時間
            start_time = cumulative_time + segment.start
            end_time = cumulative_time + segment.end
            
            # 將簡體中文轉換為繁體中文
            text_in_traditional = converter.convert(segment.text)
            
            # 輸出轉錄結果
            print(f"[{start_time:.2f}s -> {end_time:.2f}s]: {text_in_traditional}")
        
        # 更新累計時間為已處理音頻的總時長
        cumulative_time += len(audio_chunk) / SAMPLING_RATE
        
        # 模擬即時播放（延遲相當於音頻塊的持續時間）
        time.sleep(len(audio_chunk) / SAMPLING_RATE)

# 主函数

if __name__ == "__main__":
    audio_data = load_audio(AUDIO_PATH)
    simulate_realtime_transcription(audio_data, CHUNK_SIZE)
